﻿using GameEngine;
using SFML.System;

namespace MyGame
{
    public class GameScene : Scene
    {
        public GameScene()
        {
            Ship ship = new Ship();
            AddGameObject(ship);

            Meteor meteor = new Meteor(new Vector2f(800, 400));
            AddGameObject(meteor);
        }
    }
}